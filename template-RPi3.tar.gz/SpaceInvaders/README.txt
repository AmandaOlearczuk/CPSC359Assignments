Space Invaders by: Amanda Olearczuk
Note:
   - Restart functionality not working 100% - while playing the restarted
game, program suddenly exits.

   - Functionality of pressing "St" button while in-game, isn't implemented.
